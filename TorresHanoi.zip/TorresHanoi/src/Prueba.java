import fes.aragon.exep.IndiceFueraDeRango;
import fes.aragon.utilerias.dinamicas.cola.Cola;
import fes.aragon.utilerias.dinamicas.pila.Pila;

public class Prueba {
	public static void main(String[] args) {
		int n = 4;
		//Hanoi(n, "Primera torre", "Segunda torre", "Tercera torre");
		try {
			HanoidIterativo(n, "1", "2", "3");
		} catch (Exception e) {
			System.out.println("Estas mal, intentalo de nuevo");
		}
	}

	public static void Hanoi(int n, String origen, String aux, String destino) {
		if (n == 1) {
			System.out.println("Mover de la " + origen + " a la " + destino);
			return;
		}
		Hanoi(n - 1, origen, destino, aux);
		System.out.println("Mover de la " + origen + " a la " + destino);
		Hanoi(n - 1, aux, origen, destino);
	}
	
	public static void HanoidIterativo(int n, String origen, String aux, String destino) throws IndiceFueraDeRango {
		//int tope = 0;
		String varaux = "";
		boolean bandera = false;
		Pila<Integer> pilaN = new Pila<Integer>();
		Pila<String> pilaOrg = new Pila<String>();
		Pila<String>pilaAux = new Pila<String>();
		Pila<String>pilaDtn = new Pila<String>();
		while(n > 0 && bandera == false) {
			while(n > 1) {
				//tope = tope + 1;
				
				pilaN.insertar(n);
				pilaOrg.insertar(origen);
				pilaAux.insertar(aux);
				pilaDtn.insertar(destino);
				
				n -= 1;
				varaux = destino;
				destino = aux;
				aux = varaux;
			}
			
			System.out.println("mover disco de " + origen + " a " + destino);
			
			bandera = true;
			
			if(/*tope > 0*/!pilaN.estaVacia()) {
				n = pilaN.extraer();
				origen = pilaOrg.extraer();
				destino = pilaDtn.extraer();
				aux = pilaAux.extraer();
				//tope -= 1;
				
				System.out.println("mover disco de " + origen + " a " + destino);
				
				n -= 1;
				varaux = origen;
				origen = aux;
				aux = varaux;
				bandera = false;
			}
		}
	}
}